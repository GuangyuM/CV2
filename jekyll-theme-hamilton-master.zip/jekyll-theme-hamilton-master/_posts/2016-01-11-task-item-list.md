---
layout: post
title: Task Item List
tags: [to-do list]
---

This post tests the style of a task item list.

Source:

```markdown
- [x] Eating
- [ ] Walking
  - [ ] Running
- [ ] Sleeping
```

Rendered:

- [x] Eating
- [ ] Walking
  - [ ] Running
- [ ] Sleeping
