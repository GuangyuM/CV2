---
layout: archive-taxonomies
type: categories
title: Categories
permalink: /categories/
---
